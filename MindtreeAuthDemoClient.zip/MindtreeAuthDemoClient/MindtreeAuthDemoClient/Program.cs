﻿using Microsoft.AspNetCore.Http;
using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;

namespace MindtreeAuthDemoClient
{
    class Program
    {
        static void Main(string[] args)
        {
            /*            using (var client = new HttpClient())
                        {
                            var user = new User() { username = "employee2", email = "employee2@mindtree.com" };
                            client.BaseAddress = new Uri("https://localhost:44344/api/authentication/");
                            var createUserTask = client.PostAsJsonAsync<User>("create?password=Mindtree@secret123", user);
                            createUserTask.Wait();

                            var result = createUserTask.Result;
                            Console.WriteLine(result.StatusCode);
                        }*/

            Function();

            Console.ReadLine();
        }

        public static async void Function()
        {

            /*            using (var client = new HttpClient())
                        {
                            client.BaseAddress = new Uri("https://localhost:44344/api/authentication/");
                            var loginTask = client.PostAsJsonAsync<User>("login?email=employee2@mindtree.com&password=Mindtree@secret123", null);
                            loginTask.Wait();

                            var result = loginTask.Result;
                            Console.WriteLine(result.StatusCode);
                            Console.WriteLine(await result.Content.ReadAsStringAsync());

                        }*/


            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44344/api/authentication/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1OTk2NTQxMjQsImlzcyI6Im1pbmR0cmVlLmNvbSIsImF1ZCI6Im1pbmR0cmVlLmNvbSJ9.NejGRagspw9olS8--JUMcDL8q7PhCR1OY");
                var checkTask = client.PostAsJsonAsync<User>("check", null);
                checkTask.Wait();

                var result = checkTask.Result;
                Console.WriteLine(result.StatusCode);
                Console.WriteLine(await result.Content.ReadAsStringAsync());
            }


        }
    }

    public class User
    {
        public string username { get; set; }
        public string email { get; set; }
    }

}
