﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace MindtreeAuthenticationDemonstration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private UserManager<IdentityUser> _userManager = null;
        private SignInManager<IdentityUser> _signInManager = null;
        private IConfiguration _config;

        public AuthenticationController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, IConfiguration config)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _config = config;
        }

        [HttpPost("create")]
        public async Task<ActionResult> CreateNewUser([FromBody]IdentityUser identityUser,[FromQuery]string password)
        {
            var result = await _userManager.CreateAsync(identityUser,password);
            if(result.Succeeded)
            {
                return Ok();
            }
                return BadRequest();
        }

        [HttpPost("login")]
        public async Task<ActionResult> Login([FromQuery]string email,[FromQuery]string password)
        {
            var user = await _userManager.FindByEmailAsync(email);
            var result = await _signInManager.CheckPasswordSignInAsync(user, password, false);
            if(result.Succeeded)
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                  _config["Jwt:Issuer"],
                  null,
                  expires: DateTime.Now.AddMinutes(120),
                  signingCredentials: credentials);

                var tk = new JwtSecurityTokenHandler().WriteToken(token);

                return Ok(tk);
            }
                return Unauthorized();
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpPost("check")]
        public async Task<ActionResult> AuthenticatedCheck()
        {
            var user = HttpContext.User;
            return Ok(user.Identity);
        }


    }
}